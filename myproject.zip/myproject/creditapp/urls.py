'''from django.urls import path
from . import views

urlpatterns = [
    path('index/', views.index, name='index'),
    path('add_album/', views.add_album, name='add_album'),
    path('upload_file/', views.upload_file, name='upload_file'),
    path('delete/<str:file_name>/', views.delete_album, name='delete_album'),
]'''

'''from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='home'),  
    path('index/', views.index, name='index'),  
    path('add_album/', views.add_album, name='add_album'),
    path('upload_file/', views.upload_file, name='upload_file'),
    path('delete/<str:file_name>/', views.delete_album, name='delete_album'),
    path('delete_db/<int:album_id>/', views.delete_album_db, name='delete_album_db'),
    path('search/', views.search_albums, name='search_albums'),
    path('edit/<int:album_id>/', views.edit_album, name='edit_album'),
]'''


from django.urls import path
from django.contrib.auth.views import LoginView, LogoutView  # Import LogoutView here
from . import views

app_name = 'creditapp'

urlpatterns = [
    path('', views.index, name='index'),
    path('guest/', views.index_guest, name='index_guest'),
    path('admin/', views.admin_index, name='admin_index'),
    path('admin/export/', views.admin_export, name='admin_export'),
    path('add/', views.add_application, name='add_application'),
    path('<int:pk>/documents/', views.documents, name='documents'),
    path('documents/<int:pk>/delete/', views.delete_document, name='delete_document'),
    path('login/', LoginView.as_view(template_name='creditapp/login.html'), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),  # Corrected to LogoutView
    path('register/', views.register, name='register'),
]