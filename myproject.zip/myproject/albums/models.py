'''from django.db import models

class Album(models.Model):
    title = models.CharField(max_length=200)
    artist = models.CharField(max_length=200)
    year = models.IntegerField()
    tracks = models.JSONField()  # Хранит список треков как JSON

    class Meta:
        unique_together = ('title', 'artist')  # Проверка на дубликаты по title и artist
        ordering = ['title']

    def __str__(self):
        return f"{self.title} by {self.artist}"

    def to_dict(self):
        return {
            'title': self.title,
            'artist': self.artist,
            'year': self.year,
            'tracks': self.tracks,
        }
'''
from django.db import models
from django.contrib.auth.models import User

class CreditApplication(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='applications')
    amount = models.DecimalField(max_digits=10, decimal_places=2, help_text="Сумма кредита")
    description = models.TextField(help_text="Описание цели кредита")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    status = models.CharField(max_length=20, choices=[
        ('pending', 'Ожидает'),
        ('approved', 'Одобрено'),
        ('rejected', 'Отклонено'),
    ], default='pending')

    def __str__(self):
        return f"Заявка от {self.user.username} на {self.amount}"

class Document(models.Model):
    application = models.ForeignKey(CreditApplication, on_delete=models.CASCADE, related_name='documents')
    name = models.CharField(max_length=100, help_text="Название документа")
    file = models.FileField(upload_to='documents/', help_text="Файл документа")
    file_type = models.CharField(max_length=50, choices=[
        ('passport', 'Паспорт'),
        ('income', 'Справка о доходах'),
        ('other', 'Другое'),
    ], default='other')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} для заявки {self.application.id}"