'''import os
import json
import uuid
from django.shortcuts import render, redirect
from django.conf import settings
from django.core.files.storage import default_storage
from django.http import HttpResponse
from .forms import AlbumForm, UploadFileForm, ALBUM_SCHEMA
import jsonschema
from django.contrib import messages  


ALBUMS_DIR = os.path.join(settings.MEDIA_ROOT, 'albums')

def ensure_albums_dir():
    if not os.path.exists(ALBUMS_DIR):
        os.makedirs(ALBUMS_DIR)

def index(request):
    ensure_albums_dir()
    albums_data = []
    json_files = [f for f in os.listdir(ALBUMS_DIR) if f.endswith('.json')]
    
    if not json_files:
        message = "На сервере нет файлов с данными альбомов."
    else:
        message = None
        for file_name in json_files:
            file_path = os.path.join(ALBUMS_DIR, file_name)
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    albums_data.append({
                        'file_name': file_name,
                        'data': data
                    })
            except (json.JSONDecodeError, IOError):
                
                continue
    
    return render(request, 'index.html', {
        'albums': albums_data,
        'message': message
    })

def add_album(request):
    if request.method == 'POST':
        form = AlbumForm(request.POST)
        if form.is_valid():
            album_data = form.to_json()
            
            file_name = f"{uuid.uuid4()}.json"
            file_path = os.path.join(ALBUMS_DIR, file_name)
            ensure_albums_dir()
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(album_data, f, ensure_ascii=False, indent=4)
            return redirect('index')
    else:
        form = AlbumForm()
    return render(request, 'add_album.html', {'form': form})


def upload_file(request):
    print(f"Request method: {request.method}")  
    print(f"Request.FILES: {request.FILES}")    
    if request.method == 'POST':
        form = UploadFileForm(request.POST, request.FILES)
        print(f"Form is valid: {form.is_valid()}")  
        print(f"Form errors: {form.errors}")       
        if form.is_valid():
            uploaded_file = form.cleaned_data['file']
            print(f"Uploaded file: {uploaded_file}")  
            
            
            if uploaded_file is None:
                messages.error(request, "Файл не выбран или не загружен.")
                return render(request, 'upload.html', {'form': form})
            
            
            max_size = 10 * 1024 * 1024  
            try:
                print(f"File size: {uploaded_file.size}")  
                if uploaded_file.size > max_size:
                    messages.error(request, f"Файл слишком большой. Максимальный размер: {max_size // (1024*1024)} MB.")
                    return render(request, 'upload.html', {'form': form})
            except AttributeError:
                messages.error(request, "Ошибка при проверке размера файла.")
                return render(request, 'upload.html', {'form': form})
            
            try:
                content = uploaded_file.read().decode('utf-8')
                print(f"Content length: {len(content)}")  
                data = json.loads(content)  
                jsonschema.validate(instance=data, schema=ALBUM_SCHEMA) 
                
                ensure_albums_dir()
                file_name = f"{uuid.uuid4()}.json"
                file_path = os.path.join(ALBUMS_DIR, file_name)
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=4, ensure_ascii=False)  
                print(f"File saved to: {file_path}")  
                messages.success(request, "Файл успешно загружен и валидирован.")
                return redirect('index')  
            except (json.JSONDecodeError, jsonschema.ValidationError) as e:
                messages.error(request, f"Неверный формат JSON или данные не соответствуют схеме: {e}")
                return render(request, 'upload.html', {'form': form})
            except UnicodeDecodeError:
                messages.error(request, "Файл не является корректным текстовым файлом (UTF-8).")
                return render(request, 'upload.html', {'form': form})
    else:
        form = UploadFileForm()
    return render(request, 'upload.html', {'form': form})


    

def delete_album(request, file_name):
    if request.method == 'POST':
        
        safe_file_name = os.path.basename(file_name)  
        if not safe_file_name.endswith('.json'):
            messages.error(request, "Неверный файл для удаления.")
            return redirect('index')
        
        file_path = os.path.join(ALBUMS_DIR, safe_file_name)
        print(f"Попытка удалить файл: {file_path}")  
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
                print(f"Файл {safe_file_name} удалён успешно.")  
                messages.success(request, f"Альбом '{safe_file_name}' успешно удалён.")
            except OSError as e:
                print(f"Ошибка удаления: {e}")  
                messages.error(request, f"Ошибка при удалении файла: {e}")
        else:
            print(f"Файл {safe_file_name} не найден.")  
            messages.warning(request, f"Файл '{safe_file_name}' не найден.")
        return redirect('index')
    else:
        
        return redirect('index')
'''

'''import os
import json
import uuid
import glob
import jsonschema
from django.shortcuts import render, redirect, get_object_or_404
from django.conf import settings
from django.http import JsonResponse
from django.contrib import messages
from .forms import AlbumForm, UploadFileForm, EditAlbumForm, ALBUM_SCHEMA
from .models import Album
from django.conf import settings
from django.db import IntegrityError

ALBUMS_DIR = os.path.join(settings.MEDIA_ROOT, 'albums')

def ensure_albums_dir():
    if not os.path.exists(ALBUMS_DIR):
        os.makedirs(ALBUMS_DIR)

def index(request):
    source = request.GET.get('source', 'db')
    if source == 'db':
        albums = list(Album.objects.all().values())  
    elif source == 'file':
        albums = []
        media_dir = os.path.join(settings.MEDIA_ROOT, 'albums')
        if os.path.exists(media_dir):
            for file_path in glob.glob(os.path.join(media_dir, '*.json')):
                file_name = os.path.basename(file_path)
                if not file_name:  
                    continue
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    data['file_name'] = file_name
                    data['id'] = None  
                    albums.append(data)
                except (json.JSONDecodeError, FileNotFoundError, KeyError):
                    continue  
    else:
        albums = list(Album.objects.all().values())
    
    return render(request, 'index.html', {'albums': albums, 'source': source})


def add_album(request):
    if request.method == 'POST':
        form = AlbumForm(request.POST)
        if form.is_valid():
            title = form.cleaned_data['title']
            artist = form.cleaned_data['artist']
            year = form.cleaned_data['year']
            
            
            tracks_input = form.cleaned_data['tracks']
            if tracks_input is None or tracks_input == '':
                tracks = []
            else:
                
                if isinstance(tracks_input, list):
                    tracks = [track.strip() for track in tracks_input if track.strip()]
                else:
                    tracks_str = str(tracks_input)  
                    tracks = [track.strip() for track in tracks_str.split(',') if track.strip()]
            
            source = form.cleaned_data['source']
            
            if source == 'db':
                
                try:
                    album = Album.objects.create(title=title, artist=artist, year=year, tracks=tracks)
                    messages.success(request, f"Альбом '{title}' успешно добавлен в базу данных!")
                except IntegrityError:
                    messages.error(request, "Альбом с таким названием и исполнителем уже существует в базе данных!")
                    return redirect('add_album')
            else:  
                
                data = {
                    'title': title,
                    'artist': artist,
                    'year': year,
                    'tracks': tracks
                }
                
                media_dir = os.path.join(settings.MEDIA_ROOT, 'albums')
                os.makedirs(media_dir, exist_ok=True)
                existing_files = [f for f in os.listdir(media_dir) if f.startswith('album_') and f.endswith('.json')]
                next_id = len(existing_files) + 1
                file_name = f'album_{next_id}.json'
                file_path = os.path.join(media_dir, file_name)
                
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=4)
                
                messages.success(request, f"Альбом '{title}' успешно сохранён в файл {file_name}!")
            
            return redirect('index')
    else:
        form = AlbumForm()
    
    return render(request, 'add_album.html', {'form': form})
def upload_file(request):
    if request.method == 'POST':
        form = UploadFileForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded_file = form.cleaned_data['file']
            max_size = 10 * 1024 * 1024
            if uploaded_file.size > max_size:
                messages.error(request, f"Файл слишком большой. Максимальный размер: {max_size // (1024*1024)} MB.")
                return render(request, 'upload.html', {'form': form})
            try:
                content = uploaded_file.read().decode('utf-8')
                data = json.loads(content)
                jsonschema.validate(instance=data, schema=ALBUM_SCHEMA)
                ensure_albums_dir()
                file_name = f"{uuid.uuid4()}.json"
                file_path = os.path.join(ALBUMS_DIR, file_name)
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=4, ensure_ascii=False)
                messages.success(request, "Файл успешно загружен и валидирован.")
                return redirect('index')
            except (json.JSONDecodeError, jsonschema.ValidationError) as e:
                messages.error(request, f"Неверный формат JSON или данные не соответствуют схеме: {e}")
                return render(request, 'upload.html', {'form': form})
            except UnicodeDecodeError:
                messages.error(request, "Файл не является корректным текстовым файлом (UTF-8).")
                return render(request, 'upload.html', {'form': form})
    else:
        form = UploadFileForm()
    return render(request, 'upload.html', {'form': form})

def delete_album(request, file_name):
    if request.method == 'POST':
        safe_file_name = os.path.basename(file_name)
        if not safe_file_name.endswith('.json'):
            messages.error(request, "Неверный файл для удаления.")
            return redirect('index')
        file_path = os.path.join(ALBUMS_DIR, safe_file_name)
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
                messages.success(request, f"Файл '{safe_file_name}' успешно удалён.")
            except OSError as e:
                messages.error(request, f"Ошибка при удалении файла: {e}")
        else:
            messages.warning(request, f"Файл '{safe_file_name}' не найден.")
    return redirect('index')

def search_albums(request):
    query = request.GET.get('q', '')
    if query:
        albums = Album.objects.filter(title__icontains=query) | Album.objects.filter(artist__icontains=query)
    else:
        albums = Album.objects.all()
    data = [{'id': album.id, 'title': album.title, 'artist': album.artist, 'year': album.year, 'tracks': album.tracks} for album in albums]
    return JsonResponse({'albums': data})

def edit_album(request, album_id):
    album = get_object_or_404(Album, id=album_id)
    if request.method == 'POST':
       
        album.title = request.POST.get('title')
        album.artist = request.POST.get('artist')
        album.year = int(request.POST.get('year'))
        tracks_str = request.POST.get('tracks')
        album.tracks = [track.strip() for track in tracks_str.split(',')]  
        album.save()
        return redirect('index')  
    return render(request, 'edit_album.html', {'album': album})
def delete_album_db(request, album_id):
    if request.method == 'POST':  
        album = get_object_or_404(Album, id=album_id)
        album.delete()
        messages.success(request, f"Альбом '{album.title}' удалён из базы данных!")
    return redirect('index')
    '''

import os
import json
import uuid
import glob
import jsonschema
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.contrib.auth.views import LoginView as AuthLoginView, LogoutView as AuthLogoutView
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.urls import reverse_lazy
from django.http import HttpResponse
from django.shortcuts import redirect
from django.contrib import messages
from .models import CreditApplication, Document, User
from .forms import AdminExportForm, CreditApplicationForm, ApplicationFilterForm, UserRegisterForm, DocumentForm
import openpyxl
from openpyxl import Workbook

class IndexView(LoginRequiredMixin, ListView):
    model = CreditApplication
    template_name = 'creditapp/index.html'
    context_object_name = 'applications'
    paginate_by = 10

    def get_queryset(self):
        queryset = CreditApplication.objects.filter(user=self.request.user)
        form = ApplicationFilterForm(self.request.GET)
        if form.is_valid():
            status = form.cleaned_data.get('status')
            sort_by = form.cleaned_data.get('sort_by')
            if status:
                queryset = queryset.filter(status=status)
            if sort_by:
                queryset = queryset.order_by(sort_by)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['filter_form'] = ApplicationFilterForm(self.request.GET)
        return context

class IndexGuestView(ListView):
    model = CreditApplication
    template_name = 'creditapp/index_guest.html'
    context_object_name = 'applications'
    paginate_by = 10

    def get_queryset(self):
        queryset = CreditApplication.objects.filter(user__isnull=True)
        form = ApplicationFilterForm(self.request.GET)
        if form.is_valid():
            status = form.cleaned_data.get('status')
            sort_by = form.cleaned_data.get('sort_by')
            if status:
                queryset = queryset.filter(status=status)
            if sort_by:
                queryset = queryset.order_by(sort_by)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['filter_form'] = ApplicationFilterForm(self.request.GET)
        return context

class AddApplicationView(LoginRequiredMixin, CreateView):
    model = CreditApplication
    form_class = CreditApplicationForm
    template_name = 'creditapp/add_application.html'
    success_url = reverse_lazy('index')

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)

class LoginView(AuthLoginView):
    template_name = 'creditapp/login.html'
    redirect_authenticated_user = True
    success_url = reverse_lazy('index')

class RegisterView(CreateView):
    model = User
    form_class = UserRegisterForm
    template_name = 'creditapp/register.html'
    success_url = reverse_lazy('login')

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, 'Регистрация успешна! Войдите в систему.')
        return response

class DocumentsView(LoginRequiredMixin, ListView):
    model = Document
    template_name = 'creditapp/documents.html'
    context_object_name = 'documents'
    paginate_by = 10

    def get_queryset(self):
        return Document.objects.filter(application_id=self.kwargs['pk'])

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['application'] = CreditApplication.objects.get(pk=self.kwargs['pk'])
        return context

class AdminExportView(LoginRequiredMixin, UserPassesTestMixin, CreateView):
    form_class = AdminExportForm
    template_name = 'albums/admin_export.html'
    success_url = reverse_lazy('application_list')

    def test_func(self):
        return self.request.user.is_staff

    def form_valid(self, form):
        wb = Workbook()
        selected_tables = form.cleaned_data['tables']
        
        if 'applications' in selected_tables:
            ws_apps = wb.create_sheet("Applications")
            fields = form.cleaned_data.get('fields_applications', [])
            applications = CreditApplication.objects.all().select_related('user')
            for col_num, field in enumerate(fields, 1):
                ws_apps.cell(row=1, column=col_num, value=field.replace('_', ' ').title())
            for row_num, app in enumerate(applications, 2):
                for col_num, field in enumerate(fields, 1):
                    if field == 'user':
                        value = app.user.username if app.user else ''
                    else:
                        value = getattr(app, field, '')
                    ws_apps.cell(row=row_num, column=col_num, value=str(value))
        
        if 'users' in selected_tables:
            ws_users = wb.create_sheet("Users")
            fields = form.cleaned_data.get('fields_users', [])
            users = User.objects.all()
            for col_num, field in enumerate(fields, 1):
                ws_users.cell(row=1, column=col_num, value=field.replace('_', ' ').title())
            for row_num, user in enumerate(users, 2):
                for col_num, field in enumerate(fields, 1):
                    value = getattr(user, field, '')
                    ws_users.cell(row=row_num, column=col_num, value=str(value))
        
        if 'documents' in selected_tables:
            ws_docs = wb.create_sheet("Documents")
            fields = form.cleaned_data.get('fields_documents', [])
            documents = Document.objects.all().select_related('application')
            for col_num, field in enumerate(fields, 1):
                ws_docs.cell(row=1, column=col_num, value=field.replace('_', ' ').title())
            for row_num, doc in enumerate(documents, 2):
                for col_num, field in enumerate(fields, 1):
                    if field == 'application':
                        value = doc.application.full_name if doc.application else ''
                    else:
                        value = getattr(doc, field, '')
                    ws_docs.cell(row=row_num, column=col_num, value=str(value))
        
        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = 'attachment; filename=export.xlsx'
        wb.save(response)
        return response

