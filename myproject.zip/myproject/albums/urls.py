'''from django.urls import path
from . import views

urlpatterns = [
    path('index/', views.index, name='index'),
    path('add_album/', views.add_album, name='add_album'),
    path('upload_file/', views.upload_file, name='upload_file'),
    path('delete/<str:file_name>/', views.delete_album, name='delete_album'),
]'''

'''from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='home'),  
    path('index/', views.index, name='index'),  
    path('add_album/', views.add_album, name='add_album'),
    path('upload_file/', views.upload_file, name='upload_file'),
    path('delete/<str:file_name>/', views.delete_album, name='delete_album'),
    path('delete_db/<int:album_id>/', views.delete_album_db, name='delete_album_db'),
    path('search/', views.search_albums, name='search_albums'),
    path('edit/<int:album_id>/', views.edit_album, name='edit_album'),
]'''

from django.urls import path
from . import views

app_name = 'creditapp'  # Имя приложения для namespace

urlpatterns = [
    # Главная страница для аутентифицированных пользователей (список заявок)
    path('', views.IndexView.as_view(), name='index'),
    
    # Гостевой просмотр заявок
    path('guest/', views.IndexGuestView.as_view(), name='index_guest'),
    
    # Добавление заявки
    path('add/', views.AddApplicationView.as_view(), name='add_application'),
    
    # Вход в систему
    path('login/', views.LoginView.as_view(), name='login'),
    
    # Регистрация
    path('register/', views.RegisterView.as_view(), name='register'),
    
    # Документы для конкретной заявки (с ID заявки)
    path('application/<int:pk>/documents/', views.DocumentsView.as_view(), name='documents'),
    path('admin/export/', views.AdminExportView.as_view(), name='admin_export'),
    # Опционально: дополнительные пути, если нужны (например, для админа или экспорта)
    # path('admin/', views.AdminIndexView.as_view(), name='admin_index'),  # Если есть админ-панель
    #path('application/<int:pk>/edit/', views.EditApplicationView.as_view(), name='edit_application'),
    # path('application/<int:pk>/delete/', views.DeleteApplicationView.as_view(), name='delete_application'),
    # path('export/', views.ExportXLSXView.as_view(), name='export_xlsx'),
    # path('document/<int:pk>/delete/', views.DeleteDocumentView.as_view(), name='delete_document'),
]