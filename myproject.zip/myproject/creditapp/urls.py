'''from django.urls import path
from . import views

urlpatterns = [
    path('index/', views.index, name='index'),
    path('add_album/', views.add_album, name='add_album'),
    path('upload_file/', views.upload_file, name='upload_file'),
    path('delete/<str:file_name>/', views.delete_album, name='delete_album'),
]'''

'''from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='home'),  
    path('index/', views.index, name='index'),  
    path('add_album/', views.add_album, name='add_album'),
    path('upload_file/', views.upload_file, name='upload_file'),
    path('delete/<str:file_name>/', views.delete_album, name='delete_album'),
    path('delete_db/<int:album_id>/', views.delete_album_db, name='delete_album_db'),
    path('search/', views.search_albums, name='search_albums'),
    path('edit/<int:album_id>/', views.edit_album, name='edit_album'),
]'''

from django.urls import path
from django.contrib.auth.views import LoginView, LogoutView
from . import views

app_name = 'creditapp'

urlpatterns = [
    path('', views.home, name='home'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),

    path('applications/', views.application_list, name='application_list'),
    path('applications/create/', views.create_application, name='add_application'),
    path('applications/<int:pk>/', views.application_detail, name='application_detail'),

    path('applications/<int:pk>/delete/', views.delete_application, name='delete_application'),
    path('users/<int:user_id>/delete/', views.delete_user, name='delete_user'),
    path('dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('dashboard/report/', views.generate_report, name='admin_report'),
    
]
