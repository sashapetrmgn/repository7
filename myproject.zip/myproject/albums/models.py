'''from django.db import models

class Album(models.Model):
    title = models.CharField(max_length=200)
    artist = models.CharField(max_length=200)
    year = models.IntegerField()
    tracks = models.JSONField()  # Хранит список треков как JSON

    class Meta:
        unique_together = ('title', 'artist')  # Проверка на дубликаты по title и artist
        ordering = ['title']

    def __str__(self):
        return f"{self.title} by {self.artist}"

    def to_dict(self):
        return {
            'title': self.title,
            'artist': self.artist,
            'year': self.year,
            'tracks': self.tracks,
        }
'''
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import FileExtensionValidator

class BaseModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True

class User(AbstractUser):
    # Наследуем от AbstractUser для полной кастомизации
    # Добавляем related_name, чтобы избежать конфликтов с auth.User
    groups = models.ManyToManyField(
        'auth.Group',
        related_name='albums_user_set',  # Уникальное имя
        blank=True,
        help_text='The groups this user belongs to.',
        verbose_name='groups',
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='albums_user_set',  # Уникальное имя
        blank=True,
        help_text='Specific permissions for this user.',
        verbose_name='user permissions',
    )
    # Дополнительные поля, если нужны (например, phone, etc.)

class CreditApplication(BaseModel):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    full_name = models.CharField(max_length=255)
    phone = models.CharField(max_length=20)
    email = models.EmailField()
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    purpose = models.CharField(max_length=255, blank=True)  # Цель кредита
    income = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)  # Доход
    credit_history = models.TextField(blank=True)  # История кредита
    status = models.CharField(max_length=20, choices=[
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ], default='pending')
    description = models.TextField(blank=True)

    def __str__(self):
        return f"Application by {self.full_name} - {self.status}"

class Document(BaseModel):
    application = models.ForeignKey(CreditApplication, on_delete=models.CASCADE, related_name='documents')
    name = models.CharField(max_length=255)
    file = models.FileField(upload_to='documents/', validators=[FileExtensionValidator(allowed_extensions=['pdf', 'jpg', 'png', 'docx'])])
    description = models.TextField(blank=True)

    def __str__(self):
        return self.name
