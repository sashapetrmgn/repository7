'''from django.db import models

class Album(models.Model):
    title = models.CharField(max_length=200)
    artist = models.CharField(max_length=200)
    year = models.IntegerField()
    tracks = models.JSONField()  # Хранит список треков как JSON

    class Meta:
        unique_together = ('title', 'artist')  # Проверка на дубликаты по title и artist
        ordering = ['title']

    def __str__(self):
        return f"{self.title} by {self.artist}"

    def to_dict(self):
        return {
            'title': self.title,
            'artist': self.artist,
            'year': self.year,
            'tracks': self.tracks,
        }
'''
from django.db import models
from django.contrib.auth.models import AbstractUser

# Абстрактная базовая модель с общими полями
class BaseModel(models.Model):
    created_at = models.DateTimeField(null=True, auto_now_add=True, verbose_name='Дата и время создания')
    updated_at = models.DateTimeField(null=True, auto_now=True, verbose_name='Дата и время последнего обновления')

    class Meta:
        abstract = True

# Пользовательская модель
class CustomUser(AbstractUser, BaseModel):
    phone_number = models.CharField(max_length=20, blank=True, null=True, verbose_name='Номер телефона')
    date_of_birth = models.DateField(blank=True, null=True, verbose_name='Дата рождения')
    address = models.CharField(max_length=255, blank=True, null=True, verbose_name='Адрес')

    def __str__(self):
        return self.username

# Модель продукта кредита (например, виды кредитов)
class LoanProduct(BaseModel):
    name = models.CharField(null=True, max_length=100, verbose_name='Название продукта')
    max_amount = models.DecimalField(null=True, max_digits=12, decimal_places=2, verbose_name='Максимальная сумма')
    interest_rate = models.DecimalField(null=True, max_digits=4, decimal_places=2, verbose_name='Процентная ставка')
    term_months = models.IntegerField(null=True, verbose_name='Срок (мес.)')

    def __str__(self):
        return self.name

# Модель заявки на кредит
class CreditApplication(BaseModel):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, null=True, related_name='credit_applications', verbose_name='Пользователь')
    product = models.ForeignKey(LoanProduct, on_delete=models.SET_NULL, null=True, related_name='applications', verbose_name='Продукт кредита')
    full_name = models.CharField(max_length=255, null=True, verbose_name='Полное имя')
    income = models.DecimalField(max_digits=10, decimal_places=2, null=True, verbose_name='Доход')
    amount = models.DecimalField(max_digits=10, decimal_places=2, null=True, verbose_name='Сумма кредита')
    loan_term = models.IntegerField(null=True, verbose_name='Срок кредита (мес.)')
    interest_rate = models.DecimalField(max_digits=5, decimal_places=2, null=True, verbose_name='Процентная ставка')
    application_date = models.DateTimeField(auto_now_add=True, null=True, verbose_name='Дата подачи')

   
    STATUS_CHOICES = [
        ('pending', 'В ожидании'),
        ('approved', 'Одобрено'),
        ('rejected', 'Отклонено'),
    ]

   
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='pending',
        verbose_name='Статус'
    )

    def __str__(self):
        return f'Заявка {self.id} - {self.user.username}'
